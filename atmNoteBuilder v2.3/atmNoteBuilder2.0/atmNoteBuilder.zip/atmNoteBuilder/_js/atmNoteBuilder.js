$(document).ready(function () {
  "use strict";
  $( "#tabs" ).tabs();
	
  //ncr
  $(".up").attr('title', 'up and in service at login. ');
  $(".down").attr('title', 'down and out of service at login. ');
  $(".terLim").attr('title', 'Terminal is up but in limited service and may be unable to ');
  $('.panel').hide();
  $('.Rpanel').hide();
  $('.cassettesPanel').hide();
  $('.binPanel').hide();
  $('.jafPanel').hide();
  $('.sdmPanel').hide();
  $('.sdm2Panel').hide();
  $('.depmiscPanel').hide();
  $('.limPanel').hide();
  $('.miscPanel').hide();
  $('.Spanel').hide();
  $('.Fpanel').hide();
  $('.Recpanel').hide();
  $('.Cardpanel').hide();
  $('.EPPpanel').hide();
  $('.Cpanel').hide();
  $('.FCpanel').hide();
  $('.Dpanel').hide();
  $('.Hpanel').hide();
  $('.depPanel').hide();
  $(".hideRec").click(function(){ $(".Recpanel").slideToggle("fast"); });
  $(".hideCard").click(function(){ $(".Cardpanel").slideToggle("fast"); });
  $(".hideEPP").click(function(){ $(".EPPpanel").slideToggle("fast"); });
  $(".hideDep").click(function(){ $(".depPanel").slideToggle("fast"); });
  $(".hideFaults").click(function(){ $(".Fpanel").slideToggle("fast"); });
  $(".hideCleared").click(function(){ $(".FCpanel").slideToggle("fast"); });
  $(".hideTests").click(function(){ $(".Spanel").slideToggle("fast"); });
  $(".hideResults").click(function(){ $(".Rpanel").slideToggle("fast"); });
  $(".ch").click(function(){ $(".panel").slideToggle("fast"); });
  $(".cas").click(function(){ $(".cassettesPanel").slideToggle("fast"); });
  $(".bin").click(function(){ $(".binPanel").slideToggle("fast"); });
  $(".jaf").click(function(){ $(".jafPanel").slideToggle("fast"); });
  $(".sdm").click(function(){ $(".sdmPanel").slideToggle("fast"); });
  $(".sdm2").click(function(){ $(".sdm2Panel").slideToggle("fast"); });
  $(".dmisc").click(function(){ $(".depmiscPanel").slideToggle("fast"); });
  $(".lim").click(function(){ $(".limPanel").slideToggle("fast"); });
  $(".misc").click(function(){ $(".miscPanel").slideToggle("fast"); });
  $(".coin").click(function(){ $(".Cpanel").slideToggle("fast"); });
  $(".Hch").click(function(){ $(".Hpanel").slideToggle("fast"); });
 
  //diebold
  $('.Dpanel').hide();
  $('.DFpanel').hide();
  $('.DDpanel').hide();
  $('.DTpanel').hide();
  $('.DRpanel').hide();
  $(".hideDFaults").click(function(){ $(".DFpanel").slideToggle("fast"); });
  $(".hideDtests").click(function(){ $(".DTpanel").slideToggle("fast"); });
  $(".hideDresult").click(function(){ $(".DRpanel").slideToggle("fast"); });
  $(".Dch").click(function(){ $(".Dpanel").slideToggle("fast"); });
  $(".Dd").click(function(){ $(".DDpanel").slideToggle("fast"); });
	
  //hyosung
  $('.Hpanel').hide();
  $('.HTpanel').hide();
  $('.HRpanel').hide();
  $(".Hfaults").click(function(){ $(".Hpanel").slideToggle("fast"); });
  $(".Hwork").click(function(){ $(".HTpanel").slideToggle("fast"); });
  $(".Hres").click(function(){ $(".HRpanel").slideToggle("fast"); });
	
  //what happens when you click add button	
  $('.addResults').click(function () {
	$('.atmNotes').val("");
	var addFaults = "";
	var addCassettes = "";
	var addWorkStart = "";
	var addWorkTests = "";
	var addResultStart = "";
	var addResultLim = "";
	var addResultWit = "";
	var addResultPickWit = "";
	var addFixed = "";
	var addNetwork = "";
	var addLastDate = ""; 

	$('input:checkbox[name=lastFaultsNA]:checked').each(function() { addLastDate += $(this).val(); });
	$('input:checkbox[name=faultsNA]:checked').each(function() { addFaults += $(this).val(); }); 
	if ($('[name="cassettes"]').val().length > 0) { addCassettes += 'Dispenser:'; }
	$('[name="cassettes"]').each(function () { addCassettes += $(this).val(); });
	if ($('[name="cassettes"]').val().length > 0) { addCassettes += ','; } 
	if ($('[name="bins"]').val().length > 0) { addCassettes += 'Dispenser:'; }
	$('[name="bins"]').each(function () { addCassettes += $(this).val(); });
	if ($('[name="bins"]').val().length > 0) { addCassettes += ','; }
	$('[name="jaf"]').each(function () { addCassettes += $(this).val(); });
	if ($('[name="jaf"]').val().length > 0) { addCassettes += ','; } 
	$('[name="coin"]').each(function () { addCassettes += $(this).val(); });
	if ($('[name="coin"]').val().length > 0) { addCassettes += ','; }
	$('[name="sdm"]').each(function () { addFaults += $(this).val(); });
	if ($('[name="sdm"]').val().length > 0) { addFaults += ','; }
	$('[name="sdm2"]').each(function () { addFaults += $(this).val(); });
	if ($('[name="sdm2"]').val().length > 0) { addFaults += ','; }
	$('[name="dmisc"]').each(function () { addFaults += $(this).val(); });
	if ($('[name="dmisc"]').val().length > 0) { addFaults += ','; }
	$('[name="scpm"]').each(function () { addFaults += $(this).val(); });
	if ($('[name="scpm"]').val().length > 0) { addFaults += ','; }
	$('[name="scpm2"]').each(function () { addFaults += $(this).val(); });
	if ($('[name="scpm2"]').val().length > 0) { addFaults += ','; }
	$('[name="bna"]').each(function () { addFaults += $(this).val(); });
	if ($('[name="bna"]').val().length > 0) { addFaults += ','; }
	$('[name="ed"]').each(function () { addFaults += $(this).val(); });
	if ($('[name="ed"]').val().length > 0) { addFaults += ','; }
	$('[name="misc"]').each(function () { addFaults += $(this).val(); });
	if ($('[name="misc"]').val().length > 0) { addFaults += ','; }
	$('[name="rec"]').each(function () { addFaults += $(this).val(); });
	if ($('[name="rec"]').val().length > 0) { addFaults += ','; }
	$('[name="card"]').each(function () { addFaults += $(this).val(); });
	if ($('[name="card"]').val().length > 0) { addFaults += ','; }
	$('[name="epp"]').each(function () { addFaults += $(this).val(); });
	if ($('[name="epp"]').val().length > 0) { addFaults += ','; }
	$('input:checkbox[name=lastFaults]:checked').each(function() { if (addFaults !== "") { addFaults += ','; } addFaults += $(this).val(); });
	$('input:radio[name=workDone]:checked').each(function() { addWorkStart += $(this).val(); });
	$('input:checkbox[name=workDone]:checked').each(function() { addWorkStart += $(this).val(); });
	$('[name="tests"]').each(function () { addWorkTests += $(this).val(); });
	$('input:radio[name=network]:checked').each(function() { addNetwork += $(this).val(); });
	$('input:checkbox[name=result]:checked').each(function() { addResultStart += $(this).val(); });
	$('[name="pickLim"]').each(function () { addResultLim += $(this).val(); });
	$('input:radio[name=fix]:checked').each(function() { addFixed += $(this).val(); });

        //add everything to atmNotes 
		$('.atmNotes').val($('.atmNotes').val() + 'Last fault of this type: ' + $('.dateTime').val() + addLastDate + '\n\n' + 'Logged into ATM, confirmed ATM wasn\'t being used by a customer, logged in further to the maintenance software' + '\n\n' + 'Faults Present: ' + addCassettes + addFaults);

        //take out last comma at the end of faults section
		$('.atmNotes').val($('.atmNotes').val().replace(/,\s*$/, ""));

        //add everything to atmNotes
		$('.atmNotes').val($('.atmNotes').val() + '\n\n' + 'Work done: Terminal was ' + addWorkStart + 'Entered supervisor mode. Ran test(s) on the ' + addWorkTests + ', exited supervisor mode and attempted to return terminal to service' + '\n\n' + 'Result: ' + addResultStart + addResultWit + addResultPickWit + addResultLim + '\n\n' + 'ATM in service with the network: ' + addNetwork + '\n\n' + 'Fixed/Not fixed: ' + addFixed); 

        /* Select the text field */
        $('.atmNotes').select();

        /* Copy the text inside the text field */
        document.execCommand("copy");
	});
	
	$('.clear').click(function () {
		/* Select the text field */
        $('.atmNotes').val("");
	});
	
	$('.updateClip').click(function () {
		/* Select the text field */
		$('.atmNotes').select();
		
		/* Copy the text inside the text field */
		document.execCommand("copy");
	});

	$('.resetAtmNotes').click(function () {
		$('.atmNotes').val("");
		$('.dateTime').val("");
		$('.purgeBin').val("");
		$('[name=cassettes]').val("");
		$('.jams').val("");
		$('[name=coin]').val("");
		$('[name=bins]').val("");
		$('[name=jaf]').val("");
		$('[name=sdm]').val("");
		$('[name=sdm2]').val("");
		$('[name=dmisc]').val("");
		$('[name=scpm]').val("");
		$('[name=scpm2]').val("");
		$('[name=bna]').val("");
		$('[name=ed]').val("");
		$('[name=rec]').val("");
		$('[name=card]').val("");
		$('[name=epp]').val("");
		$('[name=misc]').val("");
		$('input:checkbox[name=lastFaults]').prop('checked', false);
		$('input:checkbox[name=lastFaultsNA]').prop('checked', false);
		$('input:checkbox[name=faultsNA]').prop('checked', false);
		$('input:checkbox[name=faults]').prop('checked', false);
		$('input:checkbox[name=workDone]').prop('checked', false);
		$('input:radio[name=workDone]').prop('checked', false);
		$('input:radio[name=network]').prop('checked', false);
		$('[name=tests]').val("");
		$('input:checkbox[name=result]').prop('checked', false);
		$('.pickLim').val("");
		$('.pickLim2').val("");
		$('.pickWit').val("");
		$('input:radio[name=fix]').prop('checked', false);
		$('.panel').hide();
		$('.Rpanel').hide();
		$('.cassettesPanel').hide();
		$('.binPanel').hide();
		$('.jafPanel').hide();
		$('.sdmPanel').hide();
		$('.sdm2Panel').hide();
		$('.depmiscPanel').hide();
		$('.limPanel').hide();
		$('.miscPanel').hide();
		$('.RecPanel').hide();
		$('.Spanel').hide();
		$('.Fpanel').hide();
		$('.Cpanel').hide();
		$('.Dpanel').hide();
		$('.Hpanel').hide();
		$('.FCpanel').hide();
		$('.depPanel').hide();
		$('.Recpanel').hide();
        $('.Cardpanel').hide();
        $('.EPPpanel').hide();
	});

	//waht happens when you click add button
	$('.DaddResults').click(function () {
		$('.DatmNotes').val("");
		var addFaults = "";
		var addCassettes = "";
		var addWorkStart = "";
		var addWorkTests = "";
		var addResultStart = "";
		var addResultLim = "";
		var addFixed = "";
		var addNetwork = "";
		var addLastDate = "";
		
		if ($('[name="Dcassettes"]').val() !== ''){ addCassettes += 'Dispenser: '; }
		if ($('.EJT').val() === ''){ addWorkTests += 'Entered supervisor mode, exited supervisor mode and tested all devices, '; }
		if ($('.EJT').val() === 'Replenished EJ\'s, '){ addWorkTests += 'Entered supervisor mode, replenished EJ\'s, exited supervisor mode and tested all devices, '; }
		if ($('.EJT').val() === 'Replenished EJ\'s, EJ (fault cleared), '){ addWorkTests += 'Entered supervisor mode, replenished EJ\'s, EJ fault cleared, exited supervisor mode and tested all devices, '; }
		if ($('.EJT').val() === 'Entered supervisor mode, replenished EJ\'s (attempt failed), ran EDC script, rebooted terminal'){ addWorkTests += 'Entered supervisor mode, unable to replenish EJ\'s , ran EDC script, rebooted terminal'; }
		$('[name="Dcassettes"]').each(function () { addCassettes += $(this).val(); });
		$('input:checkbox[name=Dfaults]:checked').each(function() { addFaults += $(this).val(); });
		$('.Dfaults').each(function () { addFaults += $(this).val(); });
		$('input:checkbox[name=DfaultsNA]:checked').each(function() { addFaults += $(this).val(); });
		$('input:checkbox[name=DfaultsNA2]:checked').each(function() { addLastDate += $(this).val(); });
		$('input:radio[name=DworkDone]:checked').each(function() { addWorkStart += $(this).val(); });
		$('input:checkbox[name=DworkDone]:checked').each(function() { addWorkStart += $(this).val(); });
		$('.Dtests').each(function () { addWorkTests += $(this).val(); });
		$('input:checkbox[name=Dtests]:checked').each(function() { addWorkTests += $(this).val(); });
		$('input:radio[name=Dnetwork]:checked').each(function() { addNetwork += $(this).val(); });
		$('input:checkbox[name=Dresult]:checked').each(function() { addResultStart += $(this).val(); });
		$('[name="DpickLim"]').each(function () { addResultLim += $(this).val(); });
		$('[name="DpickLim2"]').each(function () { addResultLim += $(this).val(); });
		$('input:radio[name=Dfix]:checked').each(function() { addFixed += $(this).val(); });
		
		//add everything to atmNotes 
		$('.DatmNotes').val($('.DatmNotes').val() + 'Last fault of this type: ' + $('.DdateTime').val() + addLastDate + '\n\n' + 'Logged into ATM, confirmed ATM wasn\'t being used by a customer, logged in further to the maintenance software' + '\n\n' + 'Faults present: ' + addCassettes + addFaults );
		
		//take out last comma at the end of faults section
		$('.DatmNotes').val($('.DatmNotes').val().replace(/,\s*$/, ""));
		
		//add everything to atmNotes 
		$('.DatmNotes').val($('.DatmNotes').val() + '\n\n' + 'Work done: Terminal was ' + addWorkStart + addWorkTests + '\n\n' + 'Result: ' + addResultStart + addResultLim + '\n\n' + 'ATM in service with the network: ' + addNetwork + '\n\n' + 'Fixed/Not fixed: ' + addFixed);
		
		/* Select the text field */
		$('.DatmNotes').select();
		
		/* Copy the text inside the text field */
		document.execCommand("copy");
	});
	
	$('.Dclear').click(function () {
		/* Select the text field */
        $('.DatmNotes').val("");
	});
	
	$('.DupdateClip').click(function () {
		/* Select the text field */
		$('.DatmNotes').select();
		
		/* Copy the text inside the text field */
		document.execCommand("copy");
	});
	
	$('.DresetAtmNotes').click(function () {
		$('.DatmNotes').val("");
		$('.DdateTime').val("");
		$('.Dcassette1').val("");
		$('.Dcassette2').val(""); 
		$('.Dcassette3').val(""); 
		$('.Dcassette4').val("");
		$('.Dfaults').val("");
		$('.EJT').val("");
		$('input:checkbox[name=DfaultsNA]').prop('checked', false);
		$('input:checkbox[name=DfaultsNA2]').prop('checked', false);
		$('input:checkbox[name=Dfaults]').prop('checked', false);
		$('input:checkbox[name=DworkDone]').prop('checked', false);
		$('input:radio[name=DworkDone]').prop('checked', false);
		$('input:radio[name=Dbranch]').prop('checked', false);
		$('input:radio[name=Dnetwork]').prop('checked', false);
		$('input:checkbox[name=Dtests]').prop('checked', false);
		$('.Dtests').val("");
		$('input:checkbox[name=Dresult]').prop('checked', false);
		$('.DpickLim').val("");
		$('.DpickLim2').val("");
		$('input:radio[name=Dfix]').prop('checked', false);
		$('.Dpanel').hide();
		$('.DDpanel').hide();
		$('.DRpanel').hide();
		$('.DTpanel').hide();
		$('.DFpanel').hide();
	});
	
	$('.HaddResults').click(function () {//waht happens when you click add button
		$('.HatmNotes').val("");
		var addFaults = "";
		var addCassettes = "";
		var addWorkStart = "";
		var addWorkTests = "";
		var addResultStart = "";
		var addResultLim = "";
		var addFixed = "";
		var addNetwork = "";
		var addLastDate = "";

		$('input:checkbox[name=Hfaults]:checked').each(function() { addFaults += $(this).val(); });
		$('[name="Hcassettes"]').each(function () { addCassettes += $(this).val(); });
		$('.Hfaults').each(function () { addFaults += $(this).val(); });
		$('input:checkbox[name=HfaultsNA]:checked').each(function() { addFaults += $(this).val(); });
		$('input:checkbox[name=HfaultsNA2]:checked').each(function() { addLastDate += $(this).val(); });
		$('input:radio[name=HworkDone]:checked').each(function() { addWorkStart += $(this).val(); });
		$('input:checkbox[name=HworkDone]:checked').each(function() { addWorkStart += $(this).val(); });
		$('.Htests').each(function() { addWorkTests += $(this).val(); });
		$('input:checkbox[name=Htests]:checked').each(function() { addWorkTests += $(this).val(); });
		$('input:radio[name=Hnetwork]:checked').each(function() { addNetwork += $(this).val(); });
		$('input:checkbox[name=Hresult]:checked').each(function() { addResultStart += $(this).val(); });
		$('[name="HpickLim"]').each(function () { addResultLim += $(this).val(); });
		$('[name="HpickLim2"]').each(function () { addResultLim += $(this).val(); });
		$('input:radio[name=Hfix]:checked').each(function() { addFixed += $(this).val();});
		
		//add everything to atmNotes 
		$('.HatmNotes').val($('.HatmNotes').val() + 'Last fault of this type: ' + $('.HdateTime').val() + addLastDate + '\n\n' + 'Logged into ATM, confirmed ATM wasn\'t being used by a customer, logged in further to the maintenance software' + '\n\n' + 'Faults present: ' + addFaults + addCassettes);
		
		//take out last comma at the end of faults section
		$('.HatmNotes').val($('.HatmNotes').val().replace(/,\s*$/, ""));
		
		//add everything to atmNotes 
		$('.HatmNotes').val($('.HatmNotes').val() + '\n\n' + 'Work done: Terminal was ' + addWorkStart + 'Entered supervisor mode, ' + addWorkTests + 'exited supervisor mode and returned terminal to service' + '\n\n' + 'Result: ' + addResultStart + addResultLim + '\n\n' + 'ATM in service with the network: ' + addNetwork + '\n\n' + 'Fixed/Not fixed: ' + addFixed);
		
		/* Select the text field */
		$('.HatmNotes').select();
		
		/* Copy the text inside the text field */
		document.execCommand("copy");
	});
	
	$('.Hclear').click(function () {
		/* Select the text field */
        $('.HatmNotes').val("");
	});
	
	$('.HupdateClip').click(function () {
		/* Select the text field */
		$('.HatmNotes').select();
		
		/* Copy the text inside the text field */
		document.execCommand("copy");
	});
	
	$('.HresetAtmNotes').click(function () {
		$('.HatmNotes').val("");
		$('.HdateTime').val("");
		$('.Hfaults').val("");
		$('[name=Hcassettes]').val("");
		$('.Htests').val("");
		$('input:checkbox[name=HfaultsNA]').prop('checked', false);
		$('input:checkbox[name=HfaultsNA2]').prop('checked', false);
		$('input:checkbox[name=Hfaults]').prop('checked', false);
		$('input:checkbox[name=HworkDone]').prop('checked', false);
		$('input:radio[name=HworkDone]').prop('checked', false);
		$('input:radio[name=Hbranch]').prop('checked', false);
		$('input:radio[name=Hnetwork]').prop('checked', false);
		$('input:checkbox[name=Htests]').prop('checked', false);
		$('input:checkbox[name=Hresult]').prop('checked', false);
		$('.HpickLim').val("");
		$('.HpickLim2').val("");
		$('input:radio[name=Hfix]').prop('checked', false);
		$('.Hpanel').hide();
		$('.HRpanel').hide();
		$('.HTpanel').hide();
	});
});